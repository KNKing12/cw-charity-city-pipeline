Charity City Pipeline — 3 full-board backgrounds

The Pool (levels 1–7): the_pool_background.png
The Spring (levels 8–14): the_spring_background.png
The Well (levels 15–21): the_well_background.png

Each is a 1536x1536 opaque PNG for the board container background, not individual cell tiles. Keep cells transparent and render grid lines, pipes and obstacles above the background. Use background-size: 100% 100% to fit the whole board.

These are selected and renamed from the existing seven backgrounds, not newly illustrated art.
