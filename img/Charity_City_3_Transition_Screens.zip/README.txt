Charity City Pipeline - group completion screens

Each image is 724 x 724 PNG.
the_pool_complete.png: show after level 7; next The Spring.
the_spring_complete.png: show after level 14; next The Well.
the_well_complete.png: show after level 21; full mission complete.

These are three cropped panels from the approved image with the bottom icon rows removed.
Display using object-fit: contain to avoid cropping text or buttons.
The illustrated bottom banners are part of the PNG, not interactive buttons; add an accessible clickable button separately if needed.
