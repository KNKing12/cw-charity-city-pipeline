# Charity City Pipeline — obstacle sprites

20 individual PNG assets, each with transparency, matching the illustrated gameplay world.

## Suggested use for the first seven levels

- Small cells: `boulder_small.png`, `boulder_cluster.png`, `thorn_bush_small.png`
- Wide obstacles: `fallen_log.png`, `fallen_branches.png`, `pipe_blocked.png`, `construction_barricade.png`
- Large clusters: `rubble_low.png`, `landslide_large.png`, `exposed_roots.png`
- Environmental variations: `mud_puddle.png`, `mud_trench.png`, `water_puddle.png`, `rocky_water_crossing.png`

Keep obstacles decorative and non-interactive unless the game's code specifically supports removing them. Do not change the existing obstacle placement logic when replacing graphics.

## CSS integration idea

```css
.obstacle {
  background-repeat: no-repeat;
  background-position: center;
  background-size: contain;
}
```

In JavaScript, map the obstacle type to `assets/obstacles/<filename>.png`, then set `element.style.backgroundImage = `url(...)``. Preserve board collision, occupied cells, level difficulty, and responsive sizing.

**Note:** These are artwork sprites, not tested in the live game. Image dimensions vary; fit them to the game cells.
